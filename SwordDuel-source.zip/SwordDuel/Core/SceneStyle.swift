import SpriteKit
import UIKit

enum Theme {
    static let navy = SKColor(red: 0.035, green: 0.065, blue: 0.15, alpha: 1)
    static let ice = SKColor(red: 0.46, green: 0.84, blue: 1, alpha: 1)
    static let gold = SKColor(red: 1, green: 0.79, blue: 0.38, alpha: 1)
    static let fire = SKColor(red: 1, green: 0.35, blue: 0.13, alpha: 1)
    static func label(_ text: String, size: CGFloat, color: SKColor = .white) -> SKLabelNode {
        let node = SKLabelNode(fontNamed: "Menlo-Bold")
        node.text = text
        node.fontSize = size
        node.fontColor = color
        node.verticalAlignmentMode = .center
        return node
    }
    static func button(_ text: String, at point: CGPoint, width: CGFloat = 110, action: @escaping () -> Void) -> MenuButton {
        let button = MenuButton(text: text, size: CGSize(width: width, height: 27), action: action)
        button.position = point
        return button
    }
}

final class MenuButton: SKNode {
    let action: () -> Void
    init(text: String, size: CGSize, action: @escaping () -> Void) {
        self.action = action
        super.init()
        let box = SKShapeNode(rectOf: size, cornerRadius: 3)
        box.fillColor = SKColor(red: 0.11, green: 0.18, blue: 0.31, alpha: 0.95)
        box.strokeColor = Theme.ice
        box.lineWidth = 1
        addChild(box)
        addChild(Theme.label(text, size: 10, color: Theme.gold))
    }
    required init?(coder: NSCoder) { fatalError() }
}

class GameScene: SKScene {
    override init(size: CGSize) {
        super.init(size: size)
        scaleMode = .aspectFit
        backgroundColor = Theme.navy
        isUserInteractionEnabled = true
    }
    required init?(coder: NSCoder) { fatalError() }
    func transition(to scene: SKScene) {
        scene.scaleMode = .aspectFit
        view?.presentScene(scene, transition: .fade(withDuration: 0.25))
    }
    func tappedButton(at point: CGPoint) -> Bool {
        var node: SKNode? = atPoint(point)
        while let candidate = node {
            if let button = candidate as? MenuButton { button.action(); return true }
            node = candidate.parent
        }
        return false
    }
}
