import SpriteKit
import UIKit

final class FightScene: GameScene {
    private let config: MatchConfig
    private var player: Fighter!
    private var opponent: Fighter!
    private var ai: AIController!
    private var arena = ArenaBackground()
    private var controls = TouchControls()
    private var projectiles: [Projectile] = []
    private var touchMap: [ObjectIdentifier: Control] = [:]
    private var keyMap: Set<Control> = []
    private var debugEnabled = false
    private var debugNodes: [SKNode] = []
    private var accumulator: CGFloat = 0
    private var lastUpdate: TimeInterval = 0
    private let step: CGFloat = 1.0 / 60.0
    private var hitStop: CGFloat = 0
    private var slowMotion: CGFloat = 0
    private var roundSeconds: CGFloat = 60
    private var round = 1
    private var roundEndDelay: CGFloat = -1
    private var roundResolved = false
    private var roundDraw = false
    private var pendingUlt: [(time: CGFloat, attacker: Fighter, defender: Fighter, damage: Int, first: Bool)] = []
    private var landedSerial: [ObjectIdentifier: Int] = [:]
    private var comboHits = 0
    private var comboTimer: CGFloat = 0
    private var hpFill: [SKShapeNode] = []
    private var energyFill: [SKShapeNode] = []
    private var scoreDots: [[SKShapeNode]] = [[], []]
    private var timerLabel = Theme.label("60", size: 18, color: Theme.gold)
    private var comboLabel = Theme.label("", size: 10, color: Theme.gold)
    private var announcement = Theme.label("", size: 25, color: Theme.gold)
    private var darkOverlay = SKShapeNode(rect: CGRect(x: 0, y: 0, width: 480, height: 270))
    private var shakeTime: CGFloat = 0

    init(size: CGSize, config: MatchConfig) { self.config = config; super.init(size: size) }
    required init?(coder: NSCoder) { fatalError() }
    override func didMove(to view: SKView) {
        arena.zPosition = -10; addChild(arena)
        let playerData = CharacterLibrary.all[config.playerIndex]
        let opponentData = CharacterLibrary.all[1 - config.playerIndex]
        player = Fighter(data: playerData, isPlayer: true)
        opponent = Fighter(data: opponentData, isPlayer: false)
        player.zPosition = 15; opponent.zPosition = 15
        addChild(player); addChild(opponent)
        ai = AIController(fighter: opponent, target: player, difficulty: config.difficulty)
        addChild(controls)
        setupHUD()
        darkOverlay.fillColor = .black; darkOverlay.strokeColor = .clear; darkOverlay.alpha = 0
        darkOverlay.zPosition = 40; addChild(darkOverlay)
        announcement.position = CGPoint(x: 240, y: 166); announcement.zPosition = 60; addChild(announcement)
        comboLabel.position = CGPoint(x: 138, y: 117); comboLabel.zPosition = 60; addChild(comboLabel)
        startRound()
    }
    private func setupHUD() {
        let backing = SKSpriteNode(color: Theme.navy.withAlphaComponent(0.72), size: CGSize(width: 480, height: 61))
        backing.position = CGPoint(x: 240, y: 239.5)
        backing.zPosition = 48
        addChild(backing)
        for i in 0..<2 {
            let x: CGFloat = i == 0 ? 14 : 270
            let name = Theme.label(i == 0 ? player.data.name : opponent.data.name, size: 8, color: i == 0 ? Theme.ice : Theme.fire)
            name.horizontalAlignmentMode = i == 0 ? .left : .right
            name.position = CGPoint(x: i == 0 ? x : x + 196, y: 256); name.zPosition = 50; addChild(name)
            let back = SKShapeNode(rect: CGRect(x: x, y: 237, width: 196, height: 12))
            back.fillColor = .black; back.strokeColor = Theme.gold; back.lineWidth = 1; back.zPosition = 49; addChild(back)
            let hp = SKShapeNode(rect: CGRect(x: x + 1, y: 238, width: 194, height: 10))
            hp.fillColor = i == 0 ? Theme.ice : Theme.fire; hp.strokeColor = .clear; hp.zPosition = 50; addChild(hp); hpFill.append(hp)
            let energyBack = SKShapeNode(rect: CGRect(x: x, y: 229, width: 196, height: 5))
            energyBack.fillColor = .black; energyBack.strokeColor = .clear; energyBack.zPosition = 49; addChild(energyBack)
            let energy = SKShapeNode(rect: CGRect(x: x + 1, y: 230, width: 0.1, height: 3))
            energy.fillColor = Theme.gold; energy.strokeColor = .clear; energy.zPosition = 50; addChild(energy); energyFill.append(energy)
            var dots: [SKShapeNode] = []
            for dotIndex in 0..<2 {
                let dot = SKShapeNode(circleOfRadius: 4)
                dot.position = CGPoint(x: i == 0 ? x + CGFloat(dotIndex) * 12 + 4 : x + 192 - CGFloat(dotIndex) * 12, y: 218)
                dot.fillColor = .darkGray; dot.strokeColor = Theme.gold; dot.lineWidth = 1; dot.zPosition = 50
                addChild(dot); dots.append(dot)
            }
            scoreDots[i] = dots
        }
        timerLabel.position = CGPoint(x: 240, y: 238); timerLabel.zPosition = 50; addChild(timerLabel)
    }
    private func startRound() {
        player.reset(at: 122, facing: 1); opponent.reset(at: 358, facing: -1)
        roundSeconds = 60; roundResolved = false; roundDraw = false; roundEndDelay = -1
        projectiles.forEach { $0.removeFromParent() }; projectiles.removeAll()
        pendingUlt.removeAll(); landedSerial.removeAll(); comboHits = 0; comboTimer = 0
        announcement.text = "ROUND \(round)  FIGHT!"
        announcement.alpha = 1
        announcement.run(.sequence([.wait(forDuration: 0.8), .fadeOut(withDuration: 0.3)]))
        updateHUD()
    }
    override func update(_ currentTime: TimeInterval) {
        if lastUpdate == 0 { lastUpdate = currentTime; return }
        let realDelta = min(0.1, max(0, currentTime - lastUpdate)); lastUpdate = currentTime
        if hitStop > 0 { hitStop = max(0, hitStop - CGFloat(realDelta)); return }
        if slowMotion > 0 { slowMotion = max(0, slowMotion - CGFloat(realDelta)) }
        accumulator += CGFloat(realDelta) * (slowMotion > 0 ? 0.3 : 1)
        var iterations = 0
        while accumulator >= step && iterations < 6 { fixedUpdate(step); accumulator -= step; iterations += 1 }
        if iterations == 6 { accumulator = 0 }
    }
    private func fixedUpdate(_ dt: CGFloat) {
        arena.updateFixed(dt)
        if shakeTime > 0 {
            shakeTime -= dt
            arena.position = CGPoint(x: CGFloat.random(in: -2...2), y: CGFloat.random(in: -1...1))
        } else { arena.position = .zero }
        if comboTimer > 0 { comboTimer -= dt; if comboTimer <= 0 { comboHits = 0; comboLabel.text = "" } }
        if roundEndDelay >= 0 {
            roundEndDelay -= dt
            if roundEndDelay < 0 { finishRound() }
            return
        }
        roundSeconds = max(0, roundSeconds - dt)
        applyInput()
        ai.updateFixed(dt)
        player.facing = player.position.x < opponent.position.x ? 1 : -1
        opponent.facing = -player.facing
        player.updateFixed(dt); opponent.updateFixed(dt)
        if abs(player.position.x - opponent.position.x) < 22 {
            let middle = (player.position.x + opponent.position.x) / 2
            if player.position.x < opponent.position.x { player.position.x = middle - 11; opponent.position.x = middle + 11 }
            else { player.position.x = middle + 11; opponent.position.x = middle - 11 }
        }
        handleMove(player, target: opponent)
        handleMove(opponent, target: player)
        for projectile in projectiles {
            projectile.updateFixed(dt)
            let target = projectile.owner === player ? opponent! : player!
            if !projectile.didHit && projectile.parent != nil && projectile.hitbox.intersects(target.hurtbox) {
                projectile.didHit = true
                registerHit(attacker: projectile.owner, target: target, damage: projectile.damage, knockback: projectile.direction * 48, unblockable: false)
                showEffect("skill1_impact", at: projectile.position, color: projectile.owner.data.color == "ice" ? Theme.ice : Theme.fire)
                projectile.removeFromParent()
            }
        }
        projectiles.removeAll { $0.parent == nil }
        for i in pendingUlt.indices.reversed() {
            pendingUlt[i].time -= dt
            if pendingUlt[i].time <= 0 {
                let hit = pendingUlt.remove(at: i)
                if hit.defender.hp > 0 { registerHit(attacker: hit.attacker, target: hit.defender, damage: hit.damage, knockback: hit.attacker.facing * 18, unblockable: hit.first) }
            }
        }
        controls.update(energy: player.energy, cooldowns: player.cooldowns)
        updateHUD()
        if player.hp == 0 || opponent.hp == 0 || roundSeconds <= 0 { resolveRound() }
        if debugEnabled { drawDebug() }
    }
    private func handleMove(_ attacker: Fighter, target: Fighter) {
        guard let move = attacker.currentMove, let info = attacker.data.moves[move] else { return }
        if move == "skill1", !attacker.emitted, attacker.currentFrame >= info.activeStart {
            attacker.markEmitted()
            let projectile = Projectile(owner: attacker, damage: info.damage, direction: attacker.facing)
            projectile.zPosition = 20; addChild(projectile); projectiles.append(projectile)
        }
        if move == "ult", !attacker.emitted, attacker.currentFrame >= info.activeStart {
            attacker.markEmitted(); darkOverlay.alpha = 0.65
            darkOverlay.run(.sequence([.wait(forDuration: 0.5), .fadeOut(withDuration: 0.25)]))
            let color = attacker.data.color == "ice" ? Theme.ice : Theme.fire
            let effect = EffectNode(name: "ult_\(attacker.data.color)", frames: 8, color: color, size: CGSize(width: 250, height: 130), frameTime: 0.08)
            effect.position = CGPoint(x: 240, y: 110); effect.zPosition = 45; addChild(effect)
            for (index, delay) in [CGFloat(0), 0.13, 0.26].enumerated() {
                pendingUlt.append((time: delay, attacker: attacker, defender: target, damage: index == 2 ? 11 : 12, first: index == 0))
            }
        }
        if move == "skill2", attacker.data.color == "fire", !attacker.emitted, attacker.currentFrame >= info.activeStart {
            attacker.position.x = min(454, max(26, target.position.x + (attacker.position.x < target.position.x ? 27 : -27)))
            attacker.facing = attacker.position.x < target.position.x ? 1 : -1
            attacker.markEmitted()
            showEffect("dash_trail", at: attacker.position, color: Theme.fire)
        }
        guard move != "skill1", move != "ult", let hitbox = attacker.hitbox(for: move), hitbox.intersects(target.hurtbox) else { return }
        let key = ObjectIdentifier(attacker)
        guard landedSerial[key] != attacker.attackSerial else { return }
        landedSerial[key] = attacker.attackSerial
        registerHit(attacker: attacker, target: target, damage: info.damage, knockback: attacker.facing * info.knockback, unblockable: false)
    }
    private func registerHit(attacker: Fighter, target: Fighter, damage: Int, knockback: CGFloat, unblockable: Bool) {
        let dealt = target.takeHit(damage: damage, knockback: knockback, unblockable: unblockable)
        guard dealt > 0 else { return }
        attacker.energy = min(100, attacker.energy + 8)
        hitStop = 0.06; shakeTime = 0.18
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        let position = CGPoint(x: (attacker.position.x + target.position.x) / 2, y: target.position.y + 32)
        showEffect("hit_spark", at: position, color: attacker.data.color == "ice" ? Theme.ice : Theme.fire)
        if attacker === player {
            comboHits = comboTimer > 0 ? comboHits + 1 : 1
            comboTimer = 1.1
            comboLabel.text = comboHits >= 2 ? "\(comboHits) HIT COMBO!" : ""
        }
    }
    private func showEffect(_ name: String, at point: CGPoint, color: SKColor) {
        let effect = EffectNode(name: name, frames: name == "dash_trail" ? 4 : 5, color: color, size: CGSize(width: 58, height: 58))
        effect.position = point; effect.zPosition = 35; addChild(effect)
    }
    private func resolveRound() {
        guard !roundResolved else { return }
        roundResolved = true; roundEndDelay = 1.1; slowMotion = 0.5
        roundDraw = player.hp == opponent.hp
        if !roundDraw {
            let winner = player.hp > opponent.hp ? player! : opponent!
            winner.wins += 1
            winner.victoryPose()
        }
        announcement.removeAllActions(); announcement.alpha = 1; announcement.text = roundDraw ? "DRAW" : "K.O."
        updateHUD()
    }
    private func finishRound() {
        if player.wins >= 2 || opponent.wins >= 2 || round >= 3 {
            transition(to: ResultScene(size: size, config: config, victory: player.wins >= opponent.wins))
        } else { if !roundDraw { round += 1 }; startRound() }
    }
    private func updateHUD() {
        timerLabel.text = String(Int(ceil(roundSeconds)))
        for (index, fighter) in [player!, opponent!].enumerated() {
            let x: CGFloat = index == 0 ? 15 : 271
            let hpWidth = 194 * CGFloat(fighter.hp) / 100
            let hpX = index == 0 ? x + 194 - hpWidth : x
            hpFill[index].path = CGPath(rect: CGRect(x: hpX, y: 238, width: max(0.1, hpWidth), height: 10), transform: nil)
            let energyWidth = 194 * CGFloat(fighter.energy) / 100
            let energyX = index == 0 ? x : x + 194 - energyWidth
            energyFill[index].path = CGPath(rect: CGRect(x: energyX, y: 230, width: max(0.1, energyWidth), height: 3), transform: nil)
            for dotIndex in 0..<2 { scoreDots[index][dotIndex].fillColor = fighter.wins > dotIndex ? Theme.gold : .darkGray }
        }
    }
    private func drawDebug() {
        debugNodes.forEach { $0.removeFromParent() }; debugNodes.removeAll()
        for fighter in [player!, opponent!] {
            let hurt = HitboxSystem.debugRect(fighter.hurtbox, color: .green); addChild(hurt); debugNodes.append(hurt)
            if let move = fighter.currentMove, let box = fighter.hitbox(for: move) {
                let hit = HitboxSystem.debugRect(box, color: .red); addChild(hit); debugNodes.append(hit)
            }
        }
        for projectile in projectiles { let box = HitboxSystem.debugRect(projectile.hitbox, color: .yellow); addChild(box); debugNodes.append(box) }
    }
    private func applyInput() {
        let held = Set(touchMap.values).union(keyMap)
        player.leftHeld = held.contains(.left)
        player.rightHeld = held.contains(.right)
        player.blockHeld = held.contains(.block) || held.contains(.down)
    }
    private func controlDown(_ control: Control) {
        controls.setPressed(control, true)
        switch control {
        case .up: player.jump()
        case .attack: player.attack()
        case .skill1: _ = player.use("skill1")
        case .skill2: _ = player.use("skill2")
        case .ult: _ = player.use("ult")
        case .debug:
            debugEnabled.toggle()
            if !debugEnabled { debugNodes.forEach { $0.removeFromParent() }; debugNodes.removeAll() }
        default: break
        }
        applyInput()
    }
    private func controlUp(_ control: Control) { controls.setPressed(control, false); applyInput() }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            if let control = controls.control(at: touch.location(in: self)) {
                touchMap[ObjectIdentifier(touch)] = control; controlDown(control)
            }
        }
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let id = ObjectIdentifier(touch), next = controls.control(at: touch.location(in: self))
            if touchMap[id] != next {
                if let old = touchMap[id] { touchMap.removeValue(forKey: id); controlUp(old) }
                if let next { touchMap[id] = next; controlDown(next) }
            }
        }
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches { if let old = touchMap.removeValue(forKey: ObjectIdentifier(touch)) { controlUp(old) } }
    }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) { touchesEnded(touches, with: event) }
    func keyChanged(_ key: String, down: Bool) {
        guard let control = KeyboardInput.control(for: key) else { return }
        if down { if keyMap.insert(control).inserted { controlDown(control) } }
        else { keyMap.remove(control); controlUp(control) }
    }
}
