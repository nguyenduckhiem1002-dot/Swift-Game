import SpriteKit

final class SelectScene: GameScene {
    private var choice = 0
    private var difficulty: Difficulty = .normal
    private var cards: [SKShapeNode] = []
    private var difficultyLabel = Theme.label("NORMAL", size: 9)
    override func didMove(to view: SKView) {
        let arena = ArenaBackground(); arena.zPosition = -10; arena.alpha = 0.62; addChild(arena)
        let heading = Theme.label("CHOOSE YOUR SWORDSMAN", size: 14, color: Theme.gold)
        heading.position = CGPoint(x: 240, y: 237); addChild(heading)
        for index in 0..<2 {
            let data = CharacterLibrary.all[index]
            let x: CGFloat = index == 0 ? 145 : 335
            let card = SKShapeNode(rectOf: CGSize(width: 144, height: 135), cornerRadius: 4)
            card.name = "character\(index)"
            card.position = CGPoint(x: x, y: 150)
            card.fillColor = SKColor(red: 0.08, green: 0.12, blue: 0.24, alpha: 0.9)
            card.strokeColor = index == choice ? Theme.gold : Theme.ice
            card.lineWidth = 2
            addChild(card); cards.append(card)
            let sprite = SKSpriteNode()
            SpriteSheet.shared.applyFrame(to: sprite, character: data, animation: "idle", index: 0)
            sprite.setScale(1.2)
            sprite.position = CGPoint(x: 0, y: -28)
            card.addChild(sprite)
            let label = Theme.label(data.name, size: 9, color: index == 0 ? Theme.ice : Theme.fire)
            label.position.y = -43; card.addChild(label)
            let sub = Theme.label(index == 0 ? "FROST" : "FLAME", size: 7)
            sub.position.y = -56; card.addChild(sub)
        }
        let diffButton = Theme.button("DIFFICULTY", at: CGPoint(x: 150, y: 47), width: 105) { [weak self] in self?.toggleDifficulty() }
        addChild(diffButton)
        difficultyLabel.position = CGPoint(x: 150, y: 25); addChild(difficultyLabel)
        addChild(Theme.button("FIGHT", at: CGPoint(x: 330, y: 44)) { [weak self] in
            guard let self else { return }
            self.transition(to: FightScene(size: self.size, config: MatchConfig(playerIndex: self.choice, difficulty: self.difficulty)))
        })
    }
    private func toggleDifficulty() { difficulty = difficulty == .easy ? .normal : .easy; difficultyLabel.text = difficulty.rawValue.uppercased() }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let point = touch.location(in: self)
            if tappedButton(at: point) { return }
            for index in cards.indices where cards[index].contains(point) {
                choice = index
                for i in cards.indices { cards[i].strokeColor = i == choice ? Theme.gold : Theme.ice }
                return
            }
        }
    }
}
