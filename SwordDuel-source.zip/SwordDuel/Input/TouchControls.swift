import SpriteKit

enum Control: String, CaseIterable { case left = "◀", right = "▶", up = "▲", down = "▼", attack = "ATK", skill1 = "SK1", skill2 = "SK2", ult = "ULT", block = "BLOCK", debug = "BOX" }

final class TouchControls: SKNode {
    private var buttons: [Control: SKShapeNode] = [:]
    private var labels: [Control: SKLabelNode] = [:]
    private let layout: [(Control, CGPoint, CGFloat)] = [
        (.left, CGPoint(x: 35, y: 29), 28), (.right, CGPoint(x: 94, y: 29), 28),
        (.up, CGPoint(x: 65, y: 57), 27), (.down, CGPoint(x: 65, y: 14), 21),
        (.attack, CGPoint(x: 441, y: 40), 31), (.skill1, CGPoint(x: 391, y: 70), 24),
        (.skill2, CGPoint(x: 345, y: 39), 24), (.ult, CGPoint(x: 299, y: 68), 23),
        (.block, CGPoint(x: 257, y: 28), 24), (.debug, CGPoint(x: 459, y: 248), 11)
    ]
    override init() {
        super.init()
        zPosition = 90
        for (control, point, radius) in layout {
            let node = SKShapeNode(circleOfRadius: radius)
            node.name = control.rawValue; node.position = point
            node.fillColor = SKColor(red: 0.07, green: 0.13, blue: 0.23, alpha: 0.7)
            node.strokeColor = control == .ult ? Theme.gold : Theme.ice
            node.lineWidth = 1.5
            let label = Theme.label(control.rawValue, size: control == .debug ? 5 : 8)
            node.addChild(label)
            addChild(node); buttons[control] = node; labels[control] = label
        }
    }
    required init?(coder: NSCoder) { fatalError() }
    func control(at point: CGPoint) -> Control? {
        for (control, node) in buttons where node.contains(point) { return control }
        return nil
    }
    func setPressed(_ control: Control, _ pressed: Bool) { buttons[control]?.fillColor = pressed ? Theme.ice.withAlphaComponent(0.55) : SKColor(red: 0.07, green: 0.13, blue: 0.23, alpha: 0.7) }
    func update(energy: Int, cooldowns: [String: CGFloat]) {
        buttons[.ult]?.alpha = energy >= 100 ? 1 : 0.4
        for (control, move) in [(Control.skill1, "skill1"), (.skill2, "skill2")] {
            let remaining = cooldowns[move] ?? 0
            buttons[control]?.alpha = remaining > 0 ? 0.45 : 1
            labels[control]?.text = remaining > 0 ? String(format: "%.1f", remaining) : control.rawValue
        }
    }
}
