# Kiếm Tiên Đối Kháng

A 480×270, landscape, two fighter SpriteKit test game for iPhone. All code and game data are included; no external packages are needed. Băng Kiếm Tiên uses the supplied character reference and matching supplemental poses. Missing art for other characters is drawn as labeled pixel placeholders at runtime. The arena uses a widescreen watercolor xianxia painting with a moon, spirit dragon, palaces, and drifting transparent mist. Procedural scenery is retained as a fallback.

## Run

1. Open `SwordDuel.xcodeproj` in Xcode 15 or newer.
2. Select the `SwordDuel` scheme and an iPhone Simulator running iOS 16 or newer.
3. Press Run. The app is landscape only. For a device build, set your signing team and bundle identifier in the target settings.

If `xcodebuild` uses Command Line Tools instead of Xcode, select Xcode in Settings → Locations or run with `DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer`.

## Controls

Touch the on-screen directional controls and action buttons; multi-touch allows moving while attacking. Down and BLOCK both guard. BOX toggles hitbox outlines. On a hardware keyboard: A/D move, W jump, S block, J attack, K/L skills, I ultimate, B hitbox overlay.

Light attacks chain through three hits. Skills need energy and have cooldowns. Each match is best of three 60-second rounds. The select screen offers Easy and Normal AI.

## Imported Frost character

The new Frost art is bundled as transparent atlases with per-frame foot pivots. See `Art/README.md` for source, prompts, animation mappings, and preview launch arguments. Atlas crops retain the supplied artwork's resolution and allow wide sword effects; the standard strip format below remains supported.

## Add art

Put horizontal PNG sprite strips in `SwordDuel/Resources/Assets/Characters/<charId>/<charId>_<animation>.png`. The character IDs are `frost` and `flame`. Each frame must be 64×64 pixels, and the strip width must be `64 × frame count`. All strips should face right; the game mirrors them for left-facing fighters. The runtime loader uses nearest-neighbor filtering. Transparent backgrounds are recommended. If a file is absent or too small, its labeled placeholder appears.

Animations and frame counts for each character:

| Name | Frames | FPS |
| --- | ---: | ---: |
| idle | 6 | 8 |
| walk | 8 | 12 |
| jump | 4 | 12 |
| crouch_block | 2 | 8 |
| attack1 | 5 | 14 |
| attack2 | 5 | 14 |
| attack3 | 6 | 14 |
| skill1 | 6 | 12 |
| skill2 | 6 | 14 |
| ult | 10 | 12 |
| hurt | 3 | 12 |
| ko | 6 | 10 |
| win | 6 | 8 |

Optional VFX strips go in `SwordDuel/Resources/Assets/VFX/`: `projectile_ice.png` and `projectile_fire.png` (4 frames), `hit_spark.png` and `skill1_impact.png` (5 frames), `dash_trail.png` (4 frames), and `ult_ice.png` and `ult_fire.png` (8 frames). Each frame is 96×96 pixels. Missing VFX use simple generated rectangles.

The bundled painting is `xianxia_moon_dragon.png`, with `xianxia_mist.png` as its transparent moving overlay. See `Art/Background-prompt.md` for prompts and rendering details. Replace those files to change the current arena. If the painting is removed, the legacy layered background loader becomes active.

Optional 480×270 background PNGs for that legacy loader go in `SwordDuel/Resources/Assets/Backgrounds/` as `far.png`, `mid.png`, and `near.png`. Far can be opaque; mid and near should be transparent. Near tiles horizontally. The procedural layers remain as fallbacks.

After adding PNGs, ensure they appear under the blue `Assets` folder reference in Xcode. Xcode copies that folder into the app bundle.

## Tune combat

Edit `SwordDuel/Data/Characters.json`. Each move defines `damage`, `activeStart`, `activeEnd`, `hitbox` (`x`, `y`, `w`, `h` from the fighter's feet toward its facing direction), `knockback`, `energyCost`, and `cooldown` in seconds. Animation entries define `frames`, `fps`, and `loop`. A new build loads the updated JSON; no Swift edits are required for tuning existing moves.

The Quit button calls `exit(0)` because this is a test build. Remove or replace it before any App Store submission.
